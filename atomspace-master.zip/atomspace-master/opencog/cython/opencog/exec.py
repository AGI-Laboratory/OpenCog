import warnings

from opencog.execute import *

warnings.warn('opencog.exec has been renamed to opencog.execute, update your imports.', DeprecationWarning)
