import warnings

from opencog.scheme import *

warnings.warn('opencog.scheme_wrapper has been renamed to opencog.scheme, update your imports.', DeprecationWarning)
