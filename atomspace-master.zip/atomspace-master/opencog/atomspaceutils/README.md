
AtomSpace Utilities
-------------------

This directory contains miscellaneous utilities involving the AtomSpace.
All of these functions require an AtomSpace to work.
