#!/usr/bin/env node

require('./link-parser')
