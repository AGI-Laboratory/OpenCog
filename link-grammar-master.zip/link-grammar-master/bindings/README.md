

Out-of-tree bindings:

* Ruby: See https://github.com/ged/linkparser/

* Perl: See http://search.cpan.org/~dbrian/Lingua-LinkParser/

  Note: these out-of-tree perl bindings are better, cleaner, etc. than
  the in-tree bindings here! Use those, not these!

* Lisp: See also https://github.com/wvxvw/cl-link-grammar
