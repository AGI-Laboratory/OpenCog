# Python3 bindings for Link Grammar

This directory contains a Python3 interface to the Link Grammar
C library.

Testing
=======
See the `python-examples` directory for unit tests and example usage.
