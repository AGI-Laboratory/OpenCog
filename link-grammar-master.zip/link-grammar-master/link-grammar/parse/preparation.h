/*************************************************************************/
/* Copyright (c) 2004                                                    */
/* Daniel Sleator, David Temperley, and John Lafferty                    */
/* Copyright (c) 2013 Linas Vepstas                                      */
/* All rights reserved                                                   */
/*                                                                       */
/* Use of the link grammar parsing system is subject to the terms of the */
/* license set forth in the LICENSE file included with this software.    */
/* This license allows free redistribution and use in source and binary  */
/* forms, with or without modification, subject to certain conditions.   */
/*                                                                       */
/*************************************************************************/

#ifndef _PREPARATION_H
#define _PREPARATION_H
#include "link-includes.h"

void prepare_to_parse(Sentence, Parse_Options);
bool set_connector_hash(Sentence);
void gword_record_in_connector(Sentence);
#endif /* _PREPARATION_H */
