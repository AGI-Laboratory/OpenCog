
#include "link-includes.h"

bool sane_linkage_morphism(Sentence, Linkage, Parse_Options);
